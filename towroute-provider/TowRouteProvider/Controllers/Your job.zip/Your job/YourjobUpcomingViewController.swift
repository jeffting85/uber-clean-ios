//
//  YourjobUpcomingViewController.swift
//  LinqAutoClub
//
//  Created by Admin on 07/06/18.
//  Copyright © 2018 Admin. All rights reserved.
//

import UIKit
import Material
import XLPagerTabStrip


class YourjobUpcomingViewController: UIViewController,IndicatorInfoProvider,TextFieldDelegate,UITableViewDelegate,UITableViewDataSource  {
    
    @IBOutlet var nojoblab: UILabel!
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(title: "UPCOMING")
    }
    
    var upcomingJobsarray = NSMutableArray()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.upcomingJobsarray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "upcomingJobsCell", for: indexPath) as! upcomingJobsCell
        
        let dict = upcomingJobsarray.object(at: indexPath.row) as! NSDictionary
        
        cell.category.text = dict.object(forKey: "category_name") as? String
        
        cell.category.text = cell.category.text! + " - " + (dict.object(forKey: "service_name") as! String)
        
        cell.bookingnum.text = "Booking No# " + "\(dict["booking_id"]!)"
        
        cell.date.text = dict.object(forKey: "job_date") as? String
        
        // let rating = "\(dict["rating"]!)"
        
        cell.address.text = dict.object(forKey: "customer_location") as? String
        
        cell.startbtn.tag = indexPath.row
        cell.cancelbtn.tag = indexPath.row
        
        let status = "\(dict["service_status"]!)"
        
        if status == "14" {
            
            cell.cancelbtn.isHidden = true
            cell.startbtn.isHidden = true
            cell.statuslab.isHidden = false
            cell.status.isHidden = false
            cell.status.text = "Job Cancelled"
            
        }
        else if status == "15" {
            
            cell.cancelbtn.isHidden = true
            cell.startbtn.isHidden = true
            cell.status.isHidden = false
            cell.statuslab.isHidden = false
            cell.status.text = "Driver has Cancelled Job"
            
        }
        else {
            
            cell.cancelbtn.isHidden = false
            cell.startbtn.isHidden = false
            cell.statuslab.isHidden = true
            cell.status.isHidden = true
            
        }
        
        cell.selectionStyle = .none
        
        return cell
    }
    
    @IBAction func startAct(_ sender: Any) {
        
        let dict = upcomingJobsarray.object(at: (sender as! UIButton).tag) as! NSDictionary
        
        let params = ["booking_id": "\(dict["booking_id"]!)",
                      "mode": "accept"]
        
        print("params \(params)")
        
        APIManager.shared.startJob(params: params as [String : AnyObject]) { (response) in
            print("responsese\(response)")
            
            if case let msg as String = response?["message"], msg == "Unauthenticated." {
                
                APIManager.shared.refreshToken(params: params as [String : AnyObject]) { (response) in
                    
                    if case let access_token as String = response?["access_token"] {
                        
                        APPDELEGATE.bearerToken = access_token
                        
                        USERDEFAULTS.set(access_token, forKey: "access_token")
                        
                        self.startAct(self)
                        
                    }
                        
                    else {
                        
                        self.showAlertView(title: "LINQ AUTO CLUB".localized, message: "Your session has expired. Please log in again", callback: { (check) in
                            
                            APPDELEGATE.updateLoginView()
                            
                        })
                        
                    }
                    
                }
                
            }
                
            else if case let msg as String = response?["message"], msg == "Request saved successfully." {
                
                self.upcomingJobs()
                
            }
            
        }
    }
    
    @IBAction func cancelAct(_ sender: Any) {
        
        let dict = upcomingJobsarray.object(at: (sender as! UIButton).tag) as! NSDictionary
        
        let params = ["booking_id": "\(dict["booking_id"]!)",
                     "mode": "driver"]
        
        print("params \(params)")
        
        APIManager.shared.declineJob(params: params as [String : AnyObject]) { (response) in
            print("responsese\(response)")
            
            if case let msg as String = response?["message"], msg == "Unauthenticated." {
                
                APIManager.shared.refreshToken(params: params as [String : AnyObject]) { (response) in
                    
                    if case let access_token as String = response?["access_token"] {
                        
                        APPDELEGATE.bearerToken = access_token
                        
                        USERDEFAULTS.set(access_token, forKey: "access_token")
                        
                        self.cancelAct(self)
                        
                    }
                        
                    else {
                        
                        self.showAlertView(title: "LINQ AUTO CLUB".localized, message: "Your session has expired. Please log in again", callback: { (check) in
                            
                            APPDELEGATE.updateLoginView()
                            
                        })
                        
                    }
                    
                }
                
            }
                
            else if case let msg as String = response?["message"], msg == "Cancelled successfully." {
                
                self.upcomingJobs()
                
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableViewAutomaticDimension
        
    }
    
    @IBOutlet var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.rowHeight = UITableViewAutomaticDimension;
        tableview.estimatedRowHeight = 44.0;
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        upcomingJobs()
        
    }
    
    func upcomingJobs() {
        
        let userdict = USERDEFAULTS.getLoggedUserDetails()
        
        let userid = userdict["id"] as! String
        
        let params = ["user_id": userid,
                      "mode": "driver"]
        
        print("params \(params)")
        
        APIManager.shared.upcomingJobs(params: params as [String : AnyObject]) { (response) in
            print("responsese\(response)")
            
            if case let msg as String = response?["message"], msg == "Unauthenticated." {
                
                APIManager.shared.refreshToken(params: params as [String : AnyObject]) { (response) in
                    
                    if case let access_token as String = response?["access_token"] {
                        
                        APPDELEGATE.bearerToken = access_token
                        
                        USERDEFAULTS.set(access_token, forKey: "access_token")
                        
                        self.upcomingJobs()
                        
                    }
                        
                    else {
                        
                        self.showAlertView(title: "LINQ AUTO CLUB".localized, message: "Your session has expired. Please log in again", callback: { (check) in
                            
                            APPDELEGATE.updateLoginView()
                            
                        })
                        
                    }
                    
                }
                
            }
                
            else if case let details as NSArray = response?["service_request"] {
                self.upcomingJobsarray = details.mutableCopy() as! NSMutableArray
                self.tableview.reloadData()
                self.nojoblab.isHidden = true
            }
            
            if self.upcomingJobsarray.count == 0 {
                
                self.nojoblab.isHidden = false
                self.tableview.isHidden = true
                
            }
            else {
                
                self.tableview.isHidden = false
                
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

class upcomingJobsCell: UITableViewCell {
    
    @IBOutlet var status: UILabel!
    @IBOutlet var statuslab: UILabel!
    @IBOutlet var address: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var category: UILabel!
    @IBOutlet var bookingnum: UILabel!
    @IBOutlet var startbtn: UIButton!
    @IBOutlet var cancelbtn: UIButton!
}

